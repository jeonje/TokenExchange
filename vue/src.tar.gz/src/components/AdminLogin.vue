<template>
<div>

  <div class="container-fluid">
    <div>
      <h1 id="login_text">Login</h1>
      <form autocomplete="off">
      <input id="password_input" autocomplete="off" type="password" class="form-control" v-model="password" placeholder="password 입력">
      </form>
      <button id="login_button" type="button" class="btn btn-primary btn-lg" v-on:click="login">로그인</button>
        <button id="signUp_button" type="button" class="btn btn-info btn-lg" v-on:click="signUp">회원가입</button>
    </div>
  </div>


  </div>

</div>
</template>

<script>
export default {
  data() {
    return {
      password: '',
    }
  },

  methods: {
    login: function(event) {
      if(this.$store.state.passwd == this.password)
          this.$router.push('/admin/home');
      else {
        alert("잘못된 비밀번호를 입력하셨습니다");
      }
    },
    signUp: function(event){
      this.$router.push('/signUp')
    }
  }


}
</script>

<style>
#login_text {
  position: absolute;
  top: 40%;
  left: 50%;
  transform: translate(-50%, -50%);
}

#password_input {
  width: 10%;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

#login_button {
  width: 6%;
  height: 6%;
  position: absolute;
  top: 50%;
  left: 60%;
  transform: translate(-50%, -50%);
}
#signUp_button{
  width: 8%;
  height: 6%;
  position: absolute;
  top: 65%;
  left: 50%;
  transform: translate(-50%, -50%);
}

</style>
