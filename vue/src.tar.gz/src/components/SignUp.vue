<template>
	<div class="sign-up">
		<p>
			 회원가입을 진행하세요
		</p>
		<input type="text" placeholder="Email"<br>
		<input type="password" placeholder="Password"><br>
		<button>회원가입</button>
		<span> 로그인 페이지로 돌아가기</span>
	</div>
</template>

<script>
export default {
	name: 'signUp',

	data: function() {
		return {}
	},
	methods: {}
}
</script>

<sytle scoped>
	.signUp{
		margin-top: 40px;
	}
	input{
		margin: 10px 0;
		width: 20%;
		padding: 15px;

	}
	button{
		margin-top 10px;
		width: 10%;
		cursor: pointer;
	}
	span {
		display: block;
		margin-top: 20px;
		font-size: 11px;
	}
</sytle>
