<template>
<div>

  <div class="container-fluid">

    <div class="row" style="padding:10px">
      <div class="col align-self-center">
        <img src="@/assets/logo.png">
      </div>
      <div class="col align-self-center">
        <b-link id="admin_home1" to="/admin/home">Home</b-link>
      </div>
      <div class="col align-self-center">
        <b-link id="admin_deposit1" to="/admin/deposit">입금</b-link>
      </div>
      <div class="col align-self-center">
        <b-link id="admin_withdraw1" to="/admin/withdraw">출금</b-link>
      </div>
      <div class="col align-self-center">
        <b-link id="admin_balance1" to="/admin/balance">잔액 조회</b-link>
      </div>
    </div>

    <p id="home_message">
      관리자 페이지입니다
    </p>

  </div>
<!--

  <div>
   <b-button v-b-modal.modalPopover>Show Modal</b-button>

   <b-modal id="modalPopover"  title="warning" ok-only>
     <p style="font-size: 10px; ">
       This triggers a popover on click.
     </p>
   </b-modal>
 </div>

 -->

</div>
</template>

<style>
#admin_home1,
#admin_deposit1,
#admin_withdraw1,
#admin_balance1 {
  font-size: 30px;
  color: green;
}

#home_message {
  font-size: 50px;
  font-weight: 700;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

/* .modal-body {
    margin: 20px 0;
    min-height:100px;
    min-width:100px;
}

.modal-footer {
    margin: 20px 0;
    min-height:100px;
    padding:10px;
} */
/* 
#modalPopover___BV_modal_header_{
    width: 100%;
}
#modalPopover___BV_modal_body_{
    padding: 10px;
    width: 100%;
    align:center;
}
#modalPopover___BV_modal_footer_{
  padding:30px;
  width: 100%;
}
.btn.btn-primary{
    padding-top: 5px;
    padding-bottom: 30px;
    width:20%;
} */

</style>
