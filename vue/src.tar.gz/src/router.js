import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/components/Index'
import Exchange from '@/components/Exchange'

import Send from '@/components/Send'
import Transaction from '@/components/Transaction'
import Balance from '@/components/Balance'
import AdminLogin from '@/components/AdminLogin'
import AdminHome from '@/components/AdminHome'
import AdminDeposit from '@/components/AdminDepo'
import FinalConfirm from '@/components/finalconfirm'
import AdminWithdraw from '@/components/AdminWith'
import AdminWithResult from '@/components/AdminWithResult'
import AdminBalance from '@/components/AdminBal'
import SignUp from '@/components/SignUp'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [{
      path: '/',
      name: 'Index',
      component: Index
    },
    {
      path: '/exchange',
      component: Exchange
    },
    {
      path: '/send',
      component: Send
    },
    {
      path: '/transaction',
      component: Transaction
    },
    {
      path: '/balance',
      component: Balance
    },
    {
      path: '/admin',
      component: AdminLogin
    },
    {
      path: '/admin/home',
      component: AdminHome
    },
    {
      path: '/admin/deposit',
      component: AdminDeposit
    },
    {
      path: '/admin/deposit/finalconfirm',
      component: FinalConfirm
    },

    {
      path: '/admin/withdraw',
      component: AdminWithdraw
    },
    {
      path: '/admin/withdraw/withdrawresult',
      component: AdminWithResult
    },
    {
      path: '/admin/balance',
      component: AdminBalance
    },
    {
      path: '/signUp',
      component: SignUp
    }
  ]
})
